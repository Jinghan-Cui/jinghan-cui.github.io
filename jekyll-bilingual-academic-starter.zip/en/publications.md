---
layout: default
title: Publications
permalink: /en/publications/
lang: en
---

{% include topnav.html %}

# {{ site.data.strings[page.lang].publications }}
{% assign pubs = site.data.publications %}
{% if pubs and pubs.size > 0 %}
<ol>
{% for p in pubs %}
  <li>{% include pub_item.html item=p %}</li>
{% endfor %}
</ol>
{% else %}
<p>(Edit <code>_data/publications.yml</code> to add your entries.)</p>
{% endif %}