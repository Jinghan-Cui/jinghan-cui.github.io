---
layout: default
title: Home
permalink: /en/
lang: en
---

{% include topnav.html %}

# Jinghan Cui | Academic Homepage
**{{ site.author.affiliation_en }}**  
{{ site.description }}

> Interests: Model Predictive Control (MPC), Economic MPC, RL-augmented control, wind–solar–hydrogen storage energy systems, and Vision–Language–Action (VLA) for industrial robotics.

## {{ site.data.strings[page.lang].news }}
<div class="card">
  <div class="news-item">2025-10: Bilingual site template goes live.</div>
  <div class="news-item">2025-09: Submitted a paper on EMPC with learned terminal cost.</div>
  <div class="news-item">2025-08: Launched a project on multi-scale modeling and control of wind–solar–hydrogen storage systems.</div>
</div>

## {{ site.data.strings[page.lang].experience }}
- 2023–Present: {{ site.author.affiliation_en }}  
- 2019–2023: Ph.D., Control Science & Engineering, XX University  
- 2016–2019: M.Eng. / Engineer, XX Institute  

## {{ site.data.strings[page.lang].interests }}
- Economic MPC with terminal cost shaping and stability guarantees  
- RL–MPC co-design and learning-augmented optimization  
- Multi-scale modeling, scheduling, and control for wind–solar–hydrogen storage systems  
- VLA models for industrial robotics

## {{ site.data.strings[page.lang].contact }}
- Email: {{ site.author.email }}  
- Google Scholar: [Link]({{ site.author.scholar }}) · ORCID: [Link]({{ site.author.orcid }})