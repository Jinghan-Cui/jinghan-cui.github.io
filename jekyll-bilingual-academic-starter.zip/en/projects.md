---
layout: default
title: Projects
permalink: /en/projects/
lang: en
---

{% include topnav.html %}

# {{ site.data.strings[page.lang].projects }}
<div class="grid">
  <div class="card">
    <h3>Wind–Solar–Hydrogen Storage</h3>
    <p>Multi-scale coupling and fast precise control; EMPC with RL augmentation.</p>
  </div>
  <div class="card">
    <h3>Industrial Robotics VLA</h3>
    <p>Vision–Language–Action integration for assembly/logistics.</p>
  </div>
</div>