---
layout: default
title: Research
permalink: /en/research/
lang: en
---

{% include topnav.html %}

# Selected Research Topics

### 1) Economic MPC with Learned Terminal Cost (LTC)
- Goal: Achieve economic optimality under constraints and stability.  
- Highlight: LTC approximates long-horizon value to boost short-horizon MPC.
![EMPC](../../assets/images/research_empc.png){:.rounded}
<div class="caption">Figure: EMPC-LTC schematic (replace with your image).</div>

### 2) Wind–Solar–Hydrogen Storage (WSHS) Systems
- Focus: Multi-scale coupling mechanisms, forecasting & scheduling synergy, robust/distributed MPC.
![WSHS](../../assets/images/research_wshs.png){:.rounded}

### 3) Vision–Language–Action (VLA) for Industrial Robotics
- Focus: Integrating language grounding, visual perception, and action planning for assembly/logistics.
![VLA](../../assets/images/research_vla.png){:.rounded}