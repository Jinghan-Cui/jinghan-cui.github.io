---
layout: default
title: Teaching
permalink: /en/teaching/
lang: en
---

{% include topnav.html %}

# Teaching

## {{ site.data.strings[page.lang].courses }}
- Advanced Control Theory (Graduate)
- Model Predictive Control (Graduate)
- Intelligent Control & Applications (Undergraduate)

## {{ site.data.strings[page.lang].students }}
**{{ site.data.strings[page.lang].current }}**  
- Zhang San (Class of 2024): EMPC for WSHS systems  
- Li Si (Class of 2023): RL–MPC co-design  

**{{ site.data.strings[page.lang].alumni }}**  
- Wang Wu (2022): XX Research Institute