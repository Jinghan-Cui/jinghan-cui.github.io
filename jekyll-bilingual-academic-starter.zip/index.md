---
layout: default
title: Redirect
permalink: /
---
<meta http-equiv="refresh" content="0; url=/zh/" />
<p><a href="/zh/">中文</a> | <a href="/en/">English</a></p>