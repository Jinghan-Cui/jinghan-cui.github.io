---
layout: default
title: 项目 Projects
permalink: /zh/projects/
lang: zh
---

{% include topnav.html %}

# {{ site.data.strings[page.lang].projects }}
<div class="grid">
  <div class="card">
    <h3>风-光-氢储耦合系统</h3>
    <p>跨尺度耦合机理与快速精准调控，EMPC 与 RL 融合。</p>
  </div>
  <div class="card">
    <h3>工业机器人 VLA</h3>
    <p>视觉-语言-动作一体化，面向装配/物流等场景。</p>
  </div>
</div>