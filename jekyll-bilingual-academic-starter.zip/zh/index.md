---
layout: default
title: 首页
permalink: /zh/
lang: zh
---

{% include topnav.html %}

# 崔靖涵｜学术主页
**{{ site.author.affiliation_zh }}**  
{{ site.description }}

> 研究方向：模型预测控制（MPC）、经济MPC、强化学习与生成式算法、风-光-氢储耦合系统优化与控制、机器人视觉-语言-动作模型（VLA）。

## {{ site.data.strings[page.lang].news }}
<div class="card">
  <div class="news-item">2025-10：网站（双语）模板上线。</div>
  <div class="news-item">2025-09：提交关于 EMPC+LTC 的论文（能源系统）。</div>
  <div class="news-item">2025-08：启动风-光-氢储耦合系统多尺度建模与控制课题。</div>
</div>

## {{ site.data.strings[page.lang].experience }}
- 2023–至今：{{ site.author.affiliation_zh }}  
- 2019–2023：××大学 博士（控制科学与工程）  
- 2016–2019：××单位 硕士 / 工程师  

## {{ site.data.strings[page.lang].interests }}
- 经济型模型预测控制（EMPC），学习型终端成本（LTC）与稳定性分析  
- 强化学习与 MPC 协同、RL-MPC 共设计  
- 风-光-氢储综合能源系统的多尺度建模、调度与控制  
- 视觉-语言-动作（VLA）在工业机器人中的应用

## {{ site.data.strings[page.lang].contact }}
- 邮箱：{{ site.author.email }}  
- Google Scholar：[Link]({{ site.author.scholar }}) · ORCID：[Link]({{ site.author.orcid }})