---
layout: default
title: 研究 Research
permalink: /zh/research/
lang: zh
---

{% include topnav.html %}

# 研究方向（部分）

### 1) 经济型模型预测控制（EMPC）与学习型终端成本（LTC）
- 目标：在满足约束和稳定性的前提下，实现经济性最优。  
- 亮点：LTC 估计近似无穷远代价，提高短视窗 MPC 的性能与稳健性。
![EMPC 示意](../../assets/images/research_empc.png){:.rounded}
<div class="caption">图：EMPC-LTC 框架示意（示意图，替换为你的图片）</div>

### 2) 风-光-氢储耦合系统的多尺度协同优化与控制
- 研究：跨时空尺度的耦合机理、预测与调度协同、鲁棒/分布式 MPC。
![WSHS](../../assets/images/research_wshs.png){:.rounded}

### 3) 视觉-语言-动作（VLA）在工业机器人中的应用
- 研究：将语言理解、视觉感知与动作规划融合，服务于装配/物流/操作。
![VLA](../../assets/images/research_vla.png){:.rounded}

> 可按主题拆分为子页，支持多图展示与公式说明。