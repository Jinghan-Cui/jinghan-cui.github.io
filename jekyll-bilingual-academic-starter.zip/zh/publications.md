---
layout: default
title: 论文 Publications
permalink: /zh/publications/
lang: zh
---

{% include topnav.html %}

# {{ site.data.strings[page.lang].publications }}
{% assign pubs = site.data.publications %}
{% if pubs and pubs.size > 0 %}
<ol>
{% for p in pubs %}
  <li>{% include pub_item.html item=p %}</li>
{% endfor %}
</ol>
{% else %}
<p>（请编辑 <code>_data/publications.yml</code> 添加你的论文。）</p>
{% endif %}