---
layout: default
title: 教学 Teaching
permalink: /zh/teaching/
lang: zh
---

{% include topnav.html %}

# 教学

## {{ site.data.strings[page.lang].courses }}
- 高级控制理论（研究生）
- 模型预测控制（研究生）
- 智能控制与应用（本科）

## {{ site.data.strings[page.lang].students }}
**{{ site.data.strings[page.lang].current }}**  
- 张三（2024级，课题：风-光-氢储系统 EMPC）  
- 李四（2023级，课题：RL-MPC 共设计）  

**{{ site.data.strings[page.lang].alumni }}**  
- 王五（2022届），去向：××研究院